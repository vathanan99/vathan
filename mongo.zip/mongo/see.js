function addStudent() { 
    var Tamil = Number(document.sample.Tamil.value); 
    var It = Number(document.sample.It.value); 
    var English = Number(document.sample.English.value); 
    var Maths = Number(document.sample.Maths.value); 
    var Science = Number(document.sample.Science.value); 
  
    if (isNaN(Tamil) || isNaN(It) || isNaN(English) || isNaN(Maths) || isNaN(Science)) {
      alert("Please enter valid numbers for all marks.");
      return;
    }
    
    var Total = Tamil + It + English + Maths + Science;
    var Average = Total / 5;
  
    var tr = document.createElement('tr');
    
    var td1 = tr.appendChild(document.createElement('td'));
    var td2 = tr.appendChild(document.createElement('td'));
    var td3 = tr.appendChild(document.createElement('td'));
    var td4 = tr.appendChild(document.createElement('td'));
    var td5 = tr.appendChild(document.createElement('td'));
    var td6 = tr.appendChild(document.createElement('td'));
    var td7 = tr.appendChild(document.createElement('td'));
  
    td1.innerHTML = Tamil;
    td2.innerHTML = It;
    td3.innerHTML = English;
    td4.innerHTML = Maths;
    td5.innerHTML = Science;
    td6.innerHTML = Total;
    td7.innerHTML = Average;
  
    document.getElementById("tbl").appendChild(tr);
  }