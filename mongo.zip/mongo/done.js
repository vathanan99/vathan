function user(){

    const usernameInput = document.getElementById('username').value;
    const passwordInput = document.getElementById('password').value;
    
    console.log('Username:', usernameInput.value);
    console.log('Password:', passwordInput.value);
    
    if(usernameInput==="vathanan"&& passwordInput==="123456"){
        console.log('correct');
        alert('correct')
        window.location.href='file:///home/uki/Example/see.html'
    }
    else{
        console.log('not correct');
        alert('not correct')
    }
    
    }
    
    